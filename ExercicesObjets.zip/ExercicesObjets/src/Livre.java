
public class Livre {

    private String titre;       //Attributs (variables)

    private float prix;

    private String auteur;



    public String afficher(){
        return("Le titre du livre est :"+this.titre+"\nLe prix s'élève à : "+this.prix+"€\nL'auteur est : "+this.auteur);
    }       //méthodes





    public Livre (String LAuteur, float LePrix, String LeTitre){          //Constructeur
        this.auteur = LAuteur;
        this.prix = LePrix;
        this.titre = LeTitre;
    }

}


