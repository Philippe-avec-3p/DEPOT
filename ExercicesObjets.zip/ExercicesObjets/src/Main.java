import java.util.Scanner;
public class Main {
    public static void main(String[] args) {
Scanner sc = new Scanner(System.in);
        String auteur;
        String livre;
        float prix;

        System.out.println("Donnez le titre");
        livre = sc.nextLine();
        System.out.println("Donnez l'auteur");
        auteur = sc.nextLine();
        System.out.println("Donnez le prix");
        prix = sc.nextFloat();



        Livre monLivre = new Livre(auteur, prix, livre);

        System.out.println(monLivre.afficher());




    }
}
